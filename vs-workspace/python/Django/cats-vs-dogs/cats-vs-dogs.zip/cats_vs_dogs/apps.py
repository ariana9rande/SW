from django.apps import AppConfig


class CatsVsDogsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cats_vs_dogs'
